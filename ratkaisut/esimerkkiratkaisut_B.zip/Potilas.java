public class Potilas {

	public static void main(String[] args) {
		String potilaanEtunimi = "Matti";
		String potilaanSukunimi = "Meik�l�inen";

		System.out.print(potilaanEtunimi + " " + potilaanSukunimi);

	}
}