
public class T11 {

	public static void main(String[] args) {

		/*
		 * Tee ohjelma, jossa alustetaan kolme double-tyyppist� muuttujaa:
		 * huoneenKorkeus, huoneenLeveys ja huoneenSyvyys. Aseta muuttujien
		 * arvoiksi 2.80, 4.07 ja 3.21. Laske mik� on huoneen tilavuus ja
		 * tulosta se n�yt�lle.
		 */

		double huoneenKorkeus = 2.8;
		double huoneenLeveys = 4.07;
		double huoneenSyvyys = 3.21;

		double tilavuus = huoneenKorkeus * huoneenLeveys * huoneenSyvyys;

		System.out.println("Tilavuus: " + tilavuus);

	}

}
